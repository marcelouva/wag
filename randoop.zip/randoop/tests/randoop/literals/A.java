package randoop.literals;

//Class for testing literal files.
public class A {
  
  public A(int i) {
    // Empty body.
  }
  
  public A(String s) {  }

}
