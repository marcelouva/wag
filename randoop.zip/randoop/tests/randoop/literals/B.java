package randoop.literals;

public class B {

  public void test(int i) { }
  public void test(String s) { }
  
}
