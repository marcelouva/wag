package randoop.test;

class A3 { }

