package randoop.test;

import junit.framework.TestCase;

public class EqualsToNullTests extends TestCase{

  public void test() { 
    //throw new RuntimeException();
  }

//public void test1() throws Exception {
//EqualsToNull ens= new EqualsToNull();
//Decoration checker = ens.evaluate(new Object[]{"x"});
//assertNull(checker);
//}

//public void test2() throws Exception {
//class EqualToEverything{
//@Override
//public boolean equals(Object obj) {
//return true;
//}
//}
//EqualsToNull ens= new EqualsToNull();
//Decoration checker = ens.evaluate(new Object[]{new EqualToEverything()});
//assertNotNull(checker);
//}

}
