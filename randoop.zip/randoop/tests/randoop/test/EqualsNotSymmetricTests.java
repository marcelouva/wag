package randoop.test;

import junit.framework.TestCase;

public class EqualsNotSymmetricTests extends TestCase{

  public void test() {
    //throw new RuntimeException();
  }

//public void testToString() throws Exception {
//EqualsNotSymmetric ens= new EqualsNotSymmetric();
//ens.toJunitCode("v1", "v2");
//}

//public void test1() throws Exception {
//EqualsNotSymmetric ens= new EqualsNotSymmetric();
//String checker = ens.evaluate(new Object[]{"x", "y"});
//assertNull(checker);
//}

//public void test2() throws Exception {
//EqualsNotSymmetric ens= new EqualsNotSymmetric();
//String checker = ens.evaluate(new Object[]{"x", "x"});
//assertNull(checker);
//}

//public void test3() throws Exception {
//class EqualToEveryone{
//@Override
//public boolean equals(Object obj) {
//return true;
//}
//}

//EqualsNotSymmetric ens= new EqualsNotSymmetric();
//String checker = ens.evaluate(new Object[]{new EqualToEveryone(), "y"});
//assertNotNull(checker);
//}
}
