package randoop.test.inner;

public class Outer {
    
    public Outer() { /* no body */ }
    
    public class Inner { /* no body */}
    
    public class Inner2 {
        
        public Inner2(Outer o) { /* no body */ }
    }
}
