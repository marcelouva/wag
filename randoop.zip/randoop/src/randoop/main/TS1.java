package randoop.main;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import randoop.Write;
import randoop.main.TreeMap1.Entry;


public class TS1
{
    TreeMap1 m;
    

	public TS1() {
		// TODO Auto-generated constructor stub
		m= new TreeMap1<Integer,Integer>();
	}


	 public boolean add(Integer e) {
	        return m.put(e, null)==null;
	    }

	 public TreeMap1 getm(){
		 return this.m;
	 }
	 
	 public void add3() {
		 Integer j=0;
		 if (m.getRootI()!=null){
			 Integer i =  (Integer) m.getRootI().key;
			 System.out.println("N"+Integer.toString(i));
	 }
		 
    }

	 
 




public void visitar (Entry<Integer,Integer> Nodo) throws IOException{
LinkedList <Entry<Integer,Integer>> cola= new LinkedList<Entry<Integer,Integer>>(); /* Se declara una variable "cola" de tipo "Cola" y se crea la instancia por default.*/
LinkedList <Par<Integer,Integer>> relI= new LinkedList<Par<Integer,Integer>>(); 
LinkedList <Par<Integer,Integer>> relD= new LinkedList<Par<Integer,Integer>>();
LinkedList <Par<Integer,Integer>> valores= new LinkedList<Par<Integer,Integer>>();
LinkedList <Integer> tags= new LinkedList<Integer>();
Integer t;
int i=0;
Entry<Integer,Integer> T = null; /* Se declara una variable "T"(temporal) de tipo "Nodo" con valor inicial de "null".*/

if(Nodo != null) /* Si el parametro "Nodo" es diferente de "null"...*/
	{
	cola.add(Nodo);
	tags.add(i);	
    	
	while(!(cola.isEmpty())) /* Mientras haya eleentos en la cola ...*/
	{
			T = cola.pollFirst();
			t = tags.pollFirst();
			valores.add(new Par(t,T.key));
			
			
			//System.out.println(T.key + " "); /* Se imprime en pantalla.*/
			if (T.left!= null){
				i++;
				/* Si el nodo izquierdo existe...*/
				relI.add(new Par(t,i));
				cola.add(T.left); /* se inserta el nodo izquierdo como elemento siguiente en la cola.*/
				tags.add(i);
				
				
			}
		
			
			if (T.right != null){ /* Si el nodo derecho existe...*/
			
				i++;
			/* Si el nodo izquierdo existe...*/
   				relD.add(new Par(t,i));
   				tags.add(i);
			    cola.add(T.right); /* se inserta el nodo derecho como elemento siguiente en la cola.*/
			}
				    
		    }
			
	}


int j=0;
Par<Integer,Integer> p;
String datas="";
String values="";

while(j<valores.size()){
	p= valores.get(j);
	if (j==0){
		datas=datas+"N"+Integer.toString(p.geta());
	}else{
		datas=datas+",N"+Integer.toString(p.geta());		
	}
	if (j+1!=valores.size()){
		values =values + "QF.Data_value_0 in N"+Integer.toString(p.geta())+" -> "+Integer.toString(p.getb())+" and N"+Integer.toString(p.geta())+" -> "+Integer.toString(p.getb())+" in QF.Data_value_0  and ";
	}else{
		values =values + "QF.Data_value_0 in N"+Integer.toString(p.geta())+" -> "+Integer.toString(p.getb())+" and N"+Integer.toString(p.geta())+" -> "+Integer.toString(p.getb())+" in QF.Data_value_0 ";
	}
	
	j++;
}


//linea con los one sig a insertar
datas= "one sig " + datas + " extends Data{}  "; 

String root = "";
if (Nodo!=null){
	root = "QF.thiz_0->N0 in QF.TS_root_0 and QF.TS_root_0 in QF.thiz_0->N0  ";	
}







String ri="";
j=0;
//System.out.print("QF.Data_right_0 in ");
while(j<relD.size()){
	p= relD.get(j);
	
	
	
	if (j==0){
		//System.out.print("N"+Integer.toStrig(p.geta())+"->N"+Integer.toString(p.getb()));
		ri = ri +" N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb());
	}else{
		//System.out.print(" + N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb()));
		ri = ri +" + N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb());
	
	}
	j++;
}

ri ="QF.Data_right_0 in " + ri +" and "+ri +" in QF.Data_right_0  ";




String le="";
j=0;
//System.out.print("QF.Data_right_0 in ");
while(j<relI.size()){
	p= relI.get(j);
	
	
	
	if (j==0){
		//System.out.print("N"+Integer.toStrig(p.geta())+"->N"+Integer.toString(p.getb()));
		le = le +" N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb());
	}else{
		//System.out.print(" + N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb()));
		le = le +" + N"+Integer.toString(p.geta())+"->N"+Integer.toString(p.getb());
	
	}
	j++;
}

le ="QF.Data_left_0 in " + le +" and "+le +" in QF.Data_left_0 ";
Write.contador++;
String cade="";


/*escribe un test cada 500*/
if ((Write.contador % 500)==0){
			Write.enviar_a_archivo("<INICIO> "+datas +"fact{ "+root+"} fact{ "+le +"} fact{"+ri+"} fact{" +values+"}<FINAL> ","/home/marcelo/Dropbox/unrc/Doctorado/software/wag_treesets_TS/input/examples/src/randoopStates/salida_TS.txt");

			
}
}




}



	 










	 
