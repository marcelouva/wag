package randoop.main;

import java.io.IOException;

public class Principal {

	public static void main(String[] args) {
		
	/*TS1 t  =new TS1();
	t.add(3);
	t.add(4);
	t.add(-4);
	t.add(0);
	t.add(9);
	
	
	t.add(-14);
	t.add(14);
	try {
		t.visitar(t.getm().getRootI());
	} catch (IOException e) {
		e.printStackTrace();
	}

	}
	
	*/
	Lista l=new Lista();	
	l.add(100);
	l.add(101);
	l.add(102);
	try {
		l.visitar();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
