package randoop.main;

public class Par<K,V> {
	K a;
	V b;
		public Par(K aa, V bb){
		this.a=aa;
		this.b=bb;
	}
	public K geta(){
		return this.a;
	}

	public V getb(){
		return this.b;
	}
}
