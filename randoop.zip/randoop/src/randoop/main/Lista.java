package randoop.main;
import java.io.IOException;
import java.util.LinkedList;

import randoop.Write;
import randoop.main.TreeMap1.Entry;



public class Lista {
 LinkedList<Integer> lis; 
 LinkedList <Par<Integer,Integer>> valores= new LinkedList<Par<Integer,Integer>>();

 
 public Lista(){
	 lis=new LinkedList<Integer>();
	 
 }
 
 
 public void add(int e){
	 lis.add(e);
	 
 }
 
 public void visitar () throws IOException{
	 String p="";
	 if(this.lis.isEmpty()){
		 //aca:ver que fact meter cuando es vacia la lista
	 }else{
		int j=0;
 		String datas="";
 		String values="";
 		String indices="";
 		String next="";
 		
 		
 		while(j<this.lis.size()) {
 			if ((j+2<this.lis.size())){
 				
 				next= next+"+ N"+Integer.toString(j)+"-> N"+Integer.toString(j+1);
 			}else{
 				if(j+2==this.lis.size()){
 					next= " N"+Integer.toString(j)+"-> N"+Integer.toString(j+1)+next;
 				}
 				
 			}	
 			
 			if(j==0){
 				datas=datas+"N"+Integer.toString(j);
 				indices=indices + "N"+Integer.toString(j)+"->"+Integer.toString(j);
 				values=values + "N"+Integer.toString(j)+"->"+Integer.toString(lis.get(j));
 			}else{
 				datas=datas+",N"+Integer.toString(j);
 				indices=indices + "+ N"+Integer.toString(j)+"->"+Integer.toString(j);
 				values=values + "+ N"+Integer.toString(j)+"->"+Integer.toString(lis.get(j));
 			}	
 			j++;
 		}	
 				
 		
 		next = " fact{ QF.LNode_next_0 in "+ next + " and "+next+ " in QF.LNode_next_0 } ";
 		values= " fact{ QF.LNode_value_0 in "+ values + " and "+values+ " in QF.LNode_value_0 } ";
 		indices = " fact{ QF.LNode_index_0 in "+ indices + " and "+indices+ " in QF.LNode_index_0 } ";
 		String root=" fact {QF.Lista_header_0 in QF.thiz_0 -> N0 and QF.thiz_0 -> N0 in QF.Lista_header_0 } " ;
 		datas = " one sig "+datas+" extends LNode{} ";
 		//System.out.print(next);
	    String cade = datas + root + values + indices + next;
	    Write.contador++;


	    /*escribe un test cada 500*/
	    if ((Write.contador % 500)==0){
	    			Write.enviar_a_archivo("<INICIO> "+cade+"<FINAL> ","/home/marcelo/Dropbox/unrc/Doctorado/software/wag_listas_con_seq_ok/input/examples/src/randoopStates/salida_Lista.txt");
	    }
	    
  }
}
}