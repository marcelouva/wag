package randoop.runtime;

/**
 * A message indicating that Randoop is finished generating tests.
 */
public class RandoopFinished implements IMessage {

  private static final long serialVersionUID = -2408618829353908424L;

}
