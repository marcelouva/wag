package randoop.runtime;

public class ClosingStream implements IMessage {
  
  private static final long serialVersionUID = 638560248651002139L;

}
